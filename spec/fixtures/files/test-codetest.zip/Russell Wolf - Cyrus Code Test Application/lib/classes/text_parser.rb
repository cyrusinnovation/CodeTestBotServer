class TextParser
  def initialize(input_document_folder)
    @input = input_document_folder
  end

  def execute
    output_file = File.new("../output/output.txt", "w")
    person_list_final = []

    Dir[@input].each do |f|
      people_output = parse_text(f)
      people_output.each do |p|
        person_list_final.push(p)
      end
    end 

    write_to_document(person_list_final, output_file)
  end
end