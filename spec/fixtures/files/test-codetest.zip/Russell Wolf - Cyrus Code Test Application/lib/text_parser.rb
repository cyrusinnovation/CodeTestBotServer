require './classes/person.rb'
require './classes/text_parser.rb'
require './methods/parse_text.rb'
require './methods/write_to_output.rb'

new_parse = TextParser.new('../input/*.txt')
new_parse.execute