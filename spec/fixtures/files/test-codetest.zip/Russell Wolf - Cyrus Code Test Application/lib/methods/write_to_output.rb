def write_to_document(input_array, output_document)
  #output 1
  females = []
  males = []
  output_document.write("Output 1:" + "\n")
  input_array.each do |person|
    if person.gender.downcase == "female" || person.gender.downcase == "f"
      females.push person
    else
      males.push person
    end
  end
  (females.sort_by {|person| person.last_name}).each do |person|
    write_line(person, output_document)
  end 
  (males.sort_by {|person| person.last_name}).each do |person|
    write_line(person, output_document)
  end 
  output_document.write("\n")

  #output 2
  date_list = input_array.sort_by {|person| string_to_date(person.date_of_birth) }
  output_document.write("Output 2:" + "\n")
  date_list.each do |person|
    write_line(person, output_document)
  end
  output_document.write("\n")  
  
  #output 3
  output_list = (input_array.sort_by {|person| person.last_name}).reverse
  output_document.write("Output 3:" + "\n")
  output_list.each do |person|
    write_line(person, output_document)
  end
end

def string_to_date(date_string)
  if date_string.include? "-"
    Date::strptime(date_string, "%m-%d-%Y")
  else
    Date::strptime(date_string, "%m/%d/%Y")
  end
end

def pretty_date_output(date)
  if date.include?('-')
    date.gsub!('-', '/')
    date
  else
    date
  end
end

def to_gender(string)
  if string.downcase == "m"
    "Male"
  end
  if string.downcase == "f"
    "Female"
  end
end

def write_line(person, output_document)
   output_document.write(person.last_name + " " + person.first_name + " " + person.gender + " " + pretty_date_output(person.date_of_birth) + " " + person.favorite_color + "\n")   
end 
