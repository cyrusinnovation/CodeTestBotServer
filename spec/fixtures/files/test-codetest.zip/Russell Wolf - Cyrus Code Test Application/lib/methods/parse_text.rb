def parse_text(file)
  person_list = []
  delimeter_type = sniff_delimeter(file)

  File.readlines(file).map do |line|
    person = person_constructor(line, delimeter_type)
    person_list.push(person)
  end

  return person_list
end

def person_constructor(string, delimeter_type) #you have to dynamically construct the person class based on delimeter type
  person = nil
  string = string.split(delimeter_type)
  string.each do |s|
    if s.include?("\n")
      s.gsub!(/\n/, '')
    end
  end

  case delimeter_type
  when " | "
    person = Person.new(string[0], string[1], string[2], string[3], string[4], string[5])
  when ", "
    person = Person.new(string[0], string[1], "", string[2], string[3], string[4])
  when " "
    person = Person.new(string[0], string[1], string[2], string[3], string[5], string[4])
  else
    puts "Error."
  end
  person
end

def sniff_delimeter(file)
  line = File.open(file).first
  delimeter = nil
  if line.include? " | "
    delimeter = " | "
  elsif line.include? ", "
    delimeter = ", "
  elsif line.include? " "
    delimeter = " "
  else 
    nil
  end
  delimeter
end