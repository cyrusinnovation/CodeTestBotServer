require 'test/unit'
require '../lib/classes/person.rb'
require '../lib/classes/text_parser.rb'
require '../lib/methods/parse_text.rb'
require '../lib/methods/write_to_output.rb'

class UnitTests < Test::Unit::TestCase
  def test_delimeter_sniffer
  	comma_file = './test_data/comma.txt'
  	delimeter = sniff_delimeter(comma_file)
  	assert_equal(delimeter, ", ")

  	pipe_file = './test_data/pipe.txt'
  	delimeter = sniff_delimeter(pipe_file)
  	assert_equal(delimeter, " | ")

  	space_file = './test_data/space.txt'
  	delimeter = sniff_delimeter(space_file)
  	assert_equal(delimeter, " ")
  end

  def test_pretty_date_output
  	date = pretty_date_output("12-12-1980")
  	assert_equal(date, "12/12/1980")
  end	

  def test_parse_text
  	file = './test_data/space.txt'
  	person_list = parse_text(file)
  	assert_equal(person_list.first.last_name, "Kournikova")

   	file = './test_data/comma.txt'
  	person_list = parse_text(file)
  	assert_equal(person_list.first.last_name, "Abercrombie")
  	
  	file = './test_data/pipe.txt'
  	person_list = parse_text(file)
  	assert_equal(person_list.first.last_name, "Smith")
  end
end